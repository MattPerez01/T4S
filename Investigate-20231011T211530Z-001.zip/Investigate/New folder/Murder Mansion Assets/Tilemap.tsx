<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Tilemap" tilewidth="8" tileheight="8" tilecount="768" columns="32">
 <image source="Tilemap.png" width="256" height="192"/>
</tileset>
